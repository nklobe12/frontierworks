#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -f run.sh ]; then
  curl -L -o forge-installer.jar "https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-47.3.0/forge-1.20.1-47.3.0-installer.jar"
  java -jar forge-installer.jar --installServer
  rm -f forge-installer.jar
fi
echo "eula=true" > eula.txt
echo "-Xmx6G" > user_jvm_args.txt
chmod +x run.sh
./run.sh nogui
