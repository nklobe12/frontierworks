@echo off
cd /d "%~dp0"
if not exist run.bat (
  powershell -Command "Invoke-WebRequest -Uri https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-47.3.0/forge-1.20.1-47.3.0-installer.jar -OutFile forge-installer.jar"
  java -jar forge-installer.jar --installServer
  del forge-installer.jar
)
echo eula=true> eula.txt
echo -Xmx6G> user_jvm_args.txt
call run.bat nogui
