Lodestar 0.1.0 server pack (Minecraft 1.20.1, Forge 47.3.0).

Run start.sh (Linux/macOS) or start.bat (Windows). The first run downloads and installs Forge, then starts the server. Java 17 is required.
